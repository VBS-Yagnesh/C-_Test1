﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Training_Test_1
{
    class Program
    {
        static void Main(string[] args)
        {

            //// Q1)----------------------
            //int[] arr = { 2, 5, 8 };
            //int output = arr.Sum();
            //Console.WriteLine("Sum is: " +output);

            ////Q2)--------------------
            //int[] num = { 1, 5, 1 };
            //int n = num.Length;

            //for(int i=0; i<n; i++)
            //{
            //    bool isUnique = true;
            //    for(int j=0; j<n; j++)
            //    {
            //        if(num[i] == num[j])
            //        {
            //             isUnique = false;
            //            break;
            //        }
            //        else { Console.WriteLine("Unique element: "+ num[i]); }
            //    }
            //}


            ////Q4)-------------------------
            //string password, username;
            //int attempt = 0;

            //Console.Write("Input a username: ");
            //username = Console.ReadLine();

            //Console.Write("Input a password: ");
            //password = Console.ReadLine();

            //// Default username = "abcd", password = "1234"
            //do
            //{
            //    if (username != "abcd" || password != "1234")
            //    {
            //        attempt++;
            //    }
            //    else
            //        attempt = 0;
            //}
            //while ((username == "abcd" && password == "1234") && (attempt != 3));
            //Console.Write("The password entered successfully!");

            //if (attempt == 3)
            //    Console.Write("Login attemp three or more times. Try later!");
            //else
            //    Console.Write("The password entered successfully!");
            //{
            //    Console.WriteLine("Login Successful !");
            //}
            //else { Console.WriteLine("Enter Correct Details."); }




            //Q3)---------------------------

            //int i, j;
            //int[,] arr1 = new int[3, 3];
            //Console.WriteLine("Enter elements in array: \n");
            //for( i=0; i<3; i++)
            //{
            //    for( j=0; j<3; j++)
            //    {
            //        Console.WriteLine("Elements:[{0}, {1}]: ",i,j);
            //        arr1[i, j] = Convert.ToInt32(Console.ReadLine());
            //    }
            //}
            //Console.WriteLine("Matrix is: ");
            //for(i=0; i<3; i++)
            //{
            //    Console.Write("\n");
            //    for (j=0; j<3; j++)
            //    {
            //        Console.Write("{0}\t", arr1[i,j]);
            //    }
            //    Console.Write("\n");
            //}




            //Q7)-----------------------------



        }
    }
}

